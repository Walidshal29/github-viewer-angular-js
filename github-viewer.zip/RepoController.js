(function() {

  var app = angular.module("githubViewer");

  var RepoController = function($scope, github, $routeParams) {

    var onRepoDetails = function(username, reponame) {
      github.getRepoDetails($scope.username, $scope.reponame).then(onDetails, onError);
    };

    var onDetails = function(response) {
      $scope.issues = response.data.open_issues;
    };
    
    var onContributor = function(data) {
      $scope.repo = data;
    };

    var onError = function(reason) {
      $scope.reponame = "Could NOT fetch data!";
    };
    
    $scope.username = $routeParams.username;
    $scope.reponame = $routeParams.reponame;
    github.getRepoDetails($scope.username, $scope.reponame).then(onRepoDetails, onError);
    github.getContributors($scope.username, $scope.reponame).then(onContributor, onError);
  };

  app.controller("RepoController", RepoController);

}());